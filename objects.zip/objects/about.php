<?php
require_once "render/BaseLayout.php";
BaseLayout::renderHead();
BaseLayout::renderAbout();
BaseLayout::renderFoot();