<main>
    <form action="" method="post">
        <input type="text">
        <input type="submit" value="Enviar">
    </form>
</main>