<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>TPI -render con OOP-</title>
</head>
<body>
    <header>
        <nav>
            <h1>
                <a href="home.php">
                    PHP ORIENTADO A OBJETOS
                </a>
            </h1>
        
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="universidad.php"></a></li>
            </ul>
        </nav>
    </header>