<?php

class Contact
{
    public function showContact()
    {
        $contactDir = "about.php";
        
        return $contactDir;
    }
}